-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 05, 2018 at 02:22 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `cabin2`
--

CREATE TABLE `cabin2` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `color` text NOT NULL,
  `cap` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cabin2`
--

INSERT INTO `cabin2` (`id`, `name`, `color`, `cap`) VALUES
(1, 'cabin1', '#0071c5', 10),
(2, 'cabin2', '#008000', 0),
(3, 'cabin3', '#FFD700', 10),
(4, 'cabin4', '#FF0000', 12),
(5, 'cabin1,cabin2', '#0071c5,#008000', 0),
(6, 'cabin2,cabin3', '#008000,#FFD700', 0),
(7, 'cabin3,cabin4', '#FFD700,#FF0000', 0),
(8, 'cabin1,cabin3', '#0071c5,#FFD700', 0),
(9, 'cabin1,cabin4', '#0071c5,#FF0000', 0),
(10, 'cabin1,cabin2,cabin3,cabin4', '#0071c5,#008000,#FFD700,#FF0000', 0);

-- --------------------------------------------------------

--
-- Table structure for table `client`
--

CREATE TABLE `client` (
  `id` int(10) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `phoneNum` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `client`
--

INSERT INTO `client` (`id`, `FirstName`, `LastName`, `phoneNum`, `email`) VALUES
(13, 'donia', '3alm22', '99892374928', 'sulafa.rashad@gmail.com'),
(15, 'roro', 'roro', '123456', 'nahida.khatib@ho.com'),
(16, 'ssss', 'hamoud', '8756688', 'sulafa.rashad@gmail.com'),
(17, 'roye', 'salem', '987657', 'roye_salem@gmail.com'),
(18, 'solafa', 'khatib', '8756688', 'sulafa.rashad@gmail.com'),
(22, 'roye', 'hamoud', '987657', 'skhati10@campus.haifa.ac.il');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `user` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `user`, `pass`) VALUES
(1, 'aaaaa', 'aaaaa'),
(2, 'abc', 'bds'),
(4, 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL,
  `color` varchar(50) NOT NULL,
  `client` int(11) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `title`, `start`, `end`, `color`, `client`, `price`) VALUES
(35, 'donia 3alm', '2018-07-04', '2018-07-07', '#0071c5,#008000,#FFD700,#FF0000', 13, 200),
(42, 'solafa khatib', '2018-07-16', '2018-07-19', '#FF0000', 18, 0),
(43, 'roye salem', '2018-07-10', '2018-07-13', '#0071c5', 16, 200),
(44, 'roye salem', '2018-07-01', '2018-07-04', '#FFD700', 17, 400),
(45, 'hndsat to', '2018-07-19', '2018-07-21', '#008000', 13, 0),
(46, 'sss hamoud', '2018-07-26', '2018-07-29', '#FFD700', 16, 300),
(47, 'rewaa sedani', '2018-07-11', '2018-07-14', '#FF0000', 30, 300),
(50, 'donia 3alm', '2018-07-31', '2018-08-03', '#008000', 13, 0),
(51, 'roye salem', '2018-07-31', '2018-08-03', '#FFD700', 17, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cabin2`
--
ALTER TABLE `cabin2`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UC_ordee` (`color`,`start`),
  ADD UNIQUE KEY `UC_ord2` (`color`,`end`),
  ADD UNIQUE KEY `UC_ord3` (`color`,`start`,`end`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cabin2`
--
ALTER TABLE `cabin2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `client`
--
ALTER TABLE `client`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
